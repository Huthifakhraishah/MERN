import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <>
  <h1>Hello Dojo!</h1>
  <ul>
    <li>learn react</li>
    <li>climb everst</li>
    <li>run a marathon</li>
    <li>feed the dogs</li>
    
  </ul>

    </>
    // <div className="App">
    //   <header className="App-header">
    //     <img src={logo} className="App-logo" alt="logo" />
    //     <p>
    //       Edit <code>src/App.js</code> and save to reload.
    //     </p>
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       Learn React
    //     </a>
    //   </header>
    // </div>
  );
}

export default App;
