const App = () => {
    return React.createElement("h1", {}, "Yon can now code in React");
};
ReactDOM.render(React.createElement(App), document.getElementById("root"));